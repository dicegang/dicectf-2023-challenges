#!/bin/sh

echo '  clone_newnet:false' >> /tmp/nsjail.cfg
